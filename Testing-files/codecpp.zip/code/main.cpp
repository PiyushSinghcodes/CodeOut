#include <iostream>
#include <string>

void greetUser(const std::string& name) {
    std::cout << "Hello, " << name << std::endl;
}

int main() {
    int numberOfUsers = 2;  // You can use this variable if needed for future implementations

    std::cout << "How many users will input their names?" << std::endl;
    std::string name;

    std::cout << "Enter your name: ";
    std::getline(std::cin, name);
    greetUser(name);

    return 0;
}
