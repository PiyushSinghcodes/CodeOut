import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("How many users will input their names?");
        int numberOfUsers = 2;

            System.out.println("Enter your name: ");
            String name = scanner.nextLine();
            greetUser(name);
    

        scanner.close();
    }

    public static void greetUser(String name) {
        System.out.println("Hello, " + name);
    }
}
