def greet(name):
    print("Hello, " + name + "!")

def main():
    greet("Alex")

if __name__ == "__main__":
    main()